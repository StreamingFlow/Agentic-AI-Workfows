from datetime import datetime, timezone
from dispel4py.base import ConsumerPE, GenericPE, IterativePE, ProducerPE
from dispel4py.workflow_graph import WorkflowGraph
from openai import OpenAI
import json
import os
import uuid

OUTPUT_FILE = "/content/multi_agent_results.jsonl"
FINAL_ACTIONS = ["accept", "retry", "maintenance", "notify_operator", "human_review"]


def now():
    return datetime.now(timezone.utc).isoformat()


def function_tool(name, description, properties=None, required=None):
    """Small helper that keeps the tool list readable."""
    return {
        "type": "function",
        "name": name,
        "description": description,
        "parameters": {
            "type": "object",
            "properties": properties or {},
            "required": required or [],
            "additionalProperties": False,
        },
        "strict": True,
    }


TOOLS = [
    function_tool("inspect_previous_readings", "Return the history snapshot attached to this event."),
    function_tool("compare_neighbours", "Compare this event with its attached neighbour snapshot."),
    function_tool(
        "request_measurement", "Create a simulated repeat-measurement request.",
        {"reason": {"type": "string"}}, ["reason"]),
    function_tool(
        "create_maintenance_ticket", "Create a simulated maintenance ticket.",
        {"reason": {"type": "string"},
         "priority": {"type": "string", "enum": ["low", "medium", "high"]}},
        ["reason", "priority"]),
    function_tool(
        "escalate_to_human", "Create a simulated human-review request.",
        {"reason": {"type": "string"}}, ["reason"]),
    function_tool(
        "submit_final_decision", "Finish with one bounded action and a reason.",
        {"action": {"type": "string", "enum": FINAL_ACTIONS},
         "reason": {"type": "string"}},
        ["action", "reason"]),
]


class ReadSensorDataPE(ProducerPE):
    def _process(self, inputs):
        with open(inputs["input"], encoding="utf-8") as handle:
            for event in json.load(handle):
                self.write("output", {
                    **event,
                    "routing_trace": [],
                    "audit": [f"{now()} read emitted {event['event_id']}"],
                })


class NormalizeDataPE(IterativePE):
    def _process(self, event):
        return {
            **event,
            "normalized_temperature": event["temperature"] / 40.0,
            "audit": event["audit"] + [f"{now()} temperature normalised"],
        }


class DeterministicPrecheckPE(GenericPE):
    """Three transparent rules; everything ambiguous goes to an agent."""
    def __init__(self):
        super().__init__()
        self._add_input("input")
        self._add_output("resolved")
        self._add_output("needs_agent")

    def _process(self, inputs):
        event = dict(inputs["input"])

        if event["battery"] < 10:
            return self.resolve(event, "battery_precheck", "maintenance",
                                f"Battery is {event['battery']}%, below 10%.")

        if not -40 <= event["temperature"] <= 85:
            return self.resolve(event, "temperature_precheck", "human_review",
                                "Temperature is outside the fixed plausible range.")

        note = event["diagnostic_note"].lower()
        if "routine reading" in note and "stable" in note:
            return self.resolve(event, "clear_normal_precheck", "accept",
                                "Plausible measurements and an explicitly stable routine note.")

        trace = event["routing_trace"] + [{
            "time": now(), "stage": "precheck", "rule": "no_rule_matched",
            "route": "agent"
        }]
        return {"needs_agent": {**event, "routing_trace": trace,
                                 "audit": event["audit"] + [f"{now()} routed to agent"]}}

    @staticmethod
    def resolve(event, rule, action, reason):
        trace = event["routing_trace"] + [{
            "time": now(), "stage": "precheck", "rule": rule,
            "route": "deterministic", "action": action
        }]
        return {"resolved": {
            **event, "action": action, "reason": reason,
            "decision_source": "deterministic_rule",
            "worker_pid": os.getpid(), "agent_trace": [], "tool_trace": [],
            "routing_trace": trace,
            "audit": event["audit"] + [f"{now()} {rule} selected {action}"],
        }}


class SimpleAgentPE(IterativePE):
    """One independent instance runs in each of four agent worker processes."""
    def __init__(self, model, max_rounds=6):
        super().__init__()
        self.model = model
        self.max_rounds = max_rounds
        self.client = None

    def preprocess(self):
        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY is not available to this worker.")
        self.client = OpenAI()

    def run_tool(self, name, arguments, event):
        """Execute one bounded local tool using evidence embedded in the event."""
        if name == "inspect_previous_readings":
            return {"count": len(event["previous_readings"]),
                    "readings": event["previous_readings"]}

        if name == "compare_neighbours":
            differences = [{
                "sensor_id": neighbour["sensor_id"],
                "temperature_difference": round(event["temperature"] - neighbour["temperature"], 2),
                "humidity_difference": round(event["humidity"] - neighbour["humidity"], 2),
            } for neighbour in event["neighbour_readings"]]
            return {"count": len(differences), "differences": differences,
                    "readings": event["neighbour_readings"]}

        identifiers = {
            "request_measurement": ("request_id", "RM", "repeat_measurement_requested"),
            "create_maintenance_ticket": ("ticket_id", "MT", "maintenance_ticket_created"),
            "escalate_to_human": ("review_id", "HR", "human_review_created"),
        }
        if name in identifiers:
            id_key, prefix, status = identifiers[name]
            return {id_key: f"{prefix}-{uuid.uuid4().hex[:8]}",
                    "sensor_id": event["sensor_id"], "status": status, **arguments}

        raise ValueError(f"Tool is not permitted: {name}")

    def run_agent(self, event):
        """A small model → tools → model loop with a trace of every round."""
        conversation = [{"role": "user", "content": json.dumps({
            "event_id": event["event_id"],
            "scenario_type": event["scenario_type"],
            "sensor_id": event["sensor_id"],
            "temperature": event["temperature"],
            "humidity": event["humidity"],
            "battery": event["battery"],
            "diagnostic_note": event["diagnostic_note"],
            "previous_readings_available": len(event["previous_readings"]),
            "neighbour_readings_available": len(event["neighbour_readings"]),
        }, indent=2)}]
        agent_trace, tool_trace = [], []

        instructions = """You are a bounded IoT sensor agent. Inspect previous or neighbour
evidence when it helps. For packet loss, normally request a new measurement before retry.
For likely hardware/calibration problems, normally create a maintenance ticket.
For unresolved safety ambiguity, escalate to a human. Never invent measurements.
After any needed evidence/action tools, always call submit_final_decision."""

        for round_number in range(1, self.max_rounds + 1):
            response = self.client.responses.create(
                model=self.model, instructions=instructions, input=conversation,
                tools=TOOLS, tool_choice="auto", store=False)
            calls = [item for item in response.output
                     if getattr(item, "type", None) == "function_call"]
            if not calls:
                raise RuntimeError("Agent returned no function call.")

            conversation.extend([item.model_dump(exclude_none=True)
                                 for item in response.output])
            round_trace = {"round": round_number, "calls": []}
            outputs = []

            for call in calls:
                arguments = json.loads(call.arguments)
                call_trace = {"tool": call.name, "arguments": arguments}

                if call.name == "submit_final_decision":
                    call_trace["result"] = "final_decision_accepted"
                    round_trace["calls"].append(call_trace)
                    agent_trace.append(round_trace)
                    return arguments, agent_trace, tool_trace

                result = self.run_tool(call.name, arguments, event)
                call_trace["result"] = result
                round_trace["calls"].append(call_trace)
                tool_trace.append({"round": round_number, **call_trace})
                outputs.append({"type": "function_call_output",
                                "call_id": call.call_id,
                                "output": json.dumps(result)})

            agent_trace.append(round_trace)
            conversation.extend(outputs)

        raise RuntimeError("Maximum agent rounds reached without a final decision.")

    def _process(self, event):
        if self.client is None:
            self.preprocess()
        try:
            decision, agent_trace, tool_trace = self.run_agent(event)
            return {**event, **decision, "decision_source": "openai_agent",
                    "worker_pid": os.getpid(), "agent_trace": agent_trace,
                    "tool_trace": tool_trace,
                    "audit": event["audit"] + [f"{now()} agent selected {decision['action']}"]}
        except Exception as error:
            return {**event, "action": "human_review",
                    "reason": f"Agent failure: {type(error).__name__}: {error}",
                    "decision_source": "agent_error_fallback", "worker_pid": os.getpid(),
                    "agent_trace": locals().get("agent_trace", []),
                    "tool_trace": locals().get("tool_trace", []),
                    "audit": event["audit"] + [f"{now()} safe fallback selected"]}


class MergePE(GenericPE):
    def __init__(self):
        super().__init__()
        self._add_input("deterministic")
        self._add_input("agent")
        self._add_output("output")

    def _process(self, inputs):
        value = inputs.get("deterministic", inputs.get("agent"))
        return {"output": value} if value else None


class ExecuteActionPE(IterativePE):
    def _process(self, result):
        outcomes = {
            "accept": "Reading stored as valid.",
            "retry": "Another measurement was requested.",
            "maintenance": "Maintenance workflow initiated.",
            "notify_operator": "Operator was notified.",
            "human_review": "Case sent to human review.",
        }
        return {**result, "outcome": outcomes[result["action"]],
                "audit": result["audit"] + [f"{now()} action executed"]}


class WriteResultPE(ConsumerPE):
    def _process(self, result):
        with open(OUTPUT_FILE, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(result) + "\n")


read = ReadSensorDataPE(); read.name = "read"; read.numprocesses = 1
normalise = NormalizeDataPE(); normalise.numprocesses = 3
precheck = DeterministicPrecheckPE(); precheck.numprocesses = 3
agent = SimpleAgentPE(os.environ.get("OPENAI_MODEL", "gpt-5-mini")); agent.numprocesses = 4
merge = MergePE(); merge.numprocesses = 2
execute = ExecuteActionPE(); execute.numprocesses = 2
write = WriteResultPE(); write.numprocesses = 1

graph = WorkflowGraph()
graph.connect(read, "output", normalise, "input")
graph.connect(normalise, "output", precheck, "input")
graph.connect(precheck, "resolved", merge, "deterministic")
graph.connect(precheck, "needs_agent", agent, "input")
graph.connect(agent, "output", merge, "agent")
graph.connect(merge, "output", execute, "input")
graph.connect(execute, "output", write, "input")
