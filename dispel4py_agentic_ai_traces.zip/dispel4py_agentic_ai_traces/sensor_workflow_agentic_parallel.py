
from datetime import datetime, timezone
from dispel4py.base import (
    ConsumerPE,
    GenericPE,
    IterativePE,
    ProducerPE,
)
from dispel4py.workflow_graph import WorkflowGraph
from openai import OpenAI

import json
import os
import uuid


OUTPUT_FILE = "agentic_parallel_results.jsonl"


def utc_now():
    return datetime.now(timezone.utc).isoformat()


class ReadSensorDataPE(ProducerPE):

    def __init__(self):
        super().__init__()

    def _process(self, inputs):
        file_path = inputs["input"]

        with open(file_path, "r", encoding="utf-8") as handle:
            events = json.load(handle)

        for event in events:
            self.write(
                "output",
                {
                    **event,
                    "audit": [
                        f"{utc_now()} ReadSensorDataPE emitted "
                        f"{event['event_id']}."
                    ],
                },
            )


class NormalizeDataPE(IterativePE):

    def __init__(self):
        super().__init__()

    def _process(self, event):
        result = dict(event)

        result["normalized_temperature"] = (
            result["temperature"] / 40.0
        )

        result["audit"] = list(result["audit"]) + [
            f"{utc_now()} NormalizeDataPE normalised the temperature."
        ]

        return result


class DeterministicPrecheckPE(GenericPE):

    def __init__(self):
        super().__init__()

        self._add_input("input")
        self._add_output("resolved")
        self._add_output("needs_agent")

    def _process(self, inputs):
        event = dict(inputs["input"])
        audit = list(event["audit"])

        if event["battery"] < 10:
            audit.append(
                f"{utc_now()} Battery rule selected maintenance."
            )

            return {
                "resolved": {
                    **event,
                    "action": "maintenance",
                    "reason": (
                        f"Battery is {event['battery']}%, below 10%."
                    ),
                    "decision_source": "deterministic_rule",
                    "tool_trace": [],
                    "audit": audit,
                }
            }

        if event["temperature"] < -40 or event["temperature"] > 85:
            audit.append(
                f"{utc_now()} Temperature rule selected human review."
            )

            return {
                "resolved": {
                    **event,
                    "action": "human_review",
                    "reason": (
                        "Temperature is outside the fixed plausible range."
                    ),
                    "decision_source": "deterministic_rule",
                    "tool_trace": [],
                    "audit": audit,
                }
            }

        note = event["diagnostic_note"].lower()

        clearly_normal = (
            "routine reading" in note
            and "stable" in note
            and not any(
                warning in note
                for warning in [
                    "packet",
                    "moisture",
                    "buzzing",
                    "drift",
                    "uncertain",
                    "fault",
                    "lost",
                ]
            )
        )

        if clearly_normal:
            audit.append(
                f"{utc_now()} Clear normal-reading rule selected accept."
            )

            return {
                "resolved": {
                    **event,
                    "action": "accept",
                    "reason": (
                        "The measurements are plausible and the diagnostic "
                        "note reports a stable routine reading."
                    ),
                    "decision_source": "deterministic_rule",
                    "tool_trace": [],
                    "audit": audit,
                }
            }

        audit.append(
            f"{utc_now()} Event sent to ParallelLLMSensorAgentPE."
        )

        return {
            "needs_agent": {
                **event,
                "audit": audit,
            }
        }


class ParallelLLMSensorAgentPE(IterativePE):

    FINAL_ACTIONS = {
        "accept",
        "retry",
        "maintenance",
        "notify_operator",
        "human_review",
    }

    def __init__(
        self,
        model="gpt-5-mini",
        max_rounds=5,
    ):
        super().__init__()

        self.model = model
        self.max_rounds = max_rounds
        self.client = None
        self.tools = self._build_tools()

    def preprocess(self):
        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError(
                "OPENAI_API_KEY is not available to this worker process."
            )

        self.client = OpenAI()

    def _build_tools(self):
        return [
            {
                "type": "function",
                "name": "inspect_previous_readings",
                "description": (
                    "Return the previous readings already attached "
                    "to this event."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": [],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "compare_neighbouring_sensors",
                "description": (
                    "Compare this reading with neighbouring readings "
                    "already attached to the event."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": [],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "request_another_measurement",
                "description": (
                    "Create a simulated request for a new measurement."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "reason": {"type": "string"},
                    },
                    "required": ["reason"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "create_maintenance_ticket",
                "description": (
                    "Create a simulated maintenance ticket."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "reason": {"type": "string"},
                        "priority": {
                            "type": "string",
                            "enum": ["low", "medium", "high"],
                        },
                    },
                    "required": ["reason", "priority"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "escalate_to_human",
                "description": (
                    "Create a simulated human-review request."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "reason": {"type": "string"},
                    },
                    "required": ["reason"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "submit_final_decision",
                "description": (
                    "Finish by submitting one bounded final action."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": [
                                "accept",
                                "retry",
                                "maintenance",
                                "notify_operator",
                                "human_review",
                            ],
                        },
                        "reason": {"type": "string"},
                    },
                    "required": ["action", "reason"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
        ]

    def _execute_tool(self, name, arguments, event):
        if name == "inspect_previous_readings":
            return {
                "sensor_id": event["sensor_id"],
                "count": len(event["previous_readings"]),
                "previous_readings": event["previous_readings"],
            }

        if name == "compare_neighbouring_sensors":
            comparisons = []

            for neighbour in event["neighbour_readings"]:
                comparisons.append(
                    {
                        "sensor_id": neighbour["sensor_id"],
                        "temperature_difference": round(
                            event["temperature"]
                            - neighbour["temperature"],
                            2,
                        ),
                        "humidity_difference": round(
                            event["humidity"]
                            - neighbour["humidity"],
                            2,
                        ),
                    }
                )

            return {
                "neighbours_found": len(
                    event["neighbour_readings"]
                ),
                "neighbour_readings": event[
                    "neighbour_readings"
                ],
                "differences": comparisons,
            }

        if name == "request_another_measurement":
            return {
                "request_id": f"RM-{uuid.uuid4().hex[:10]}",
                "sensor_id": event["sensor_id"],
                "reason": arguments["reason"],
                "status": "simulated_request_created",
            }

        if name == "create_maintenance_ticket":
            return {
                "ticket_id": f"MT-{uuid.uuid4().hex[:10]}",
                "sensor_id": event["sensor_id"],
                "reason": arguments["reason"],
                "priority": arguments["priority"],
                "status": "simulated_ticket_created",
            }

        if name == "escalate_to_human":
            return {
                "review_id": f"HR-{uuid.uuid4().hex[:10]}",
                "sensor_id": event["sensor_id"],
                "reason": arguments["reason"],
                "status": "simulated_review_created",
            }

        raise ValueError(f"Tool is not permitted: {name}")

    def _process(self, event):
        if self.client is None:
            self.preprocess()

        current = dict(event)
        audit = list(current["audit"])
        tool_trace = []
        final_decision = None

        instructions = """
You are a bounded IoT sensor agent inside a parallel dispel4py workflow.

The event already contains previous_readings and neighbour_readings.
Use the tools to inspect that evidence when useful.

Rules:
- Never invent or modify measurements.
- Use evidence before deciding about warnings or faults.
- Packet-loss cases normally require another measurement and retry.
- Likely equipment or calibration problems may require maintenance.
- Ambiguous or safety-relevant cases must go to human review.
- Finish by calling submit_final_decision.
"""

        first_input = json.dumps(
            {
                "event_id": current["event_id"],
                "sensor_id": current["sensor_id"],
                "temperature": current["temperature"],
                "humidity": current["humidity"],
                "battery": current["battery"],
                "diagnostic_note": current["diagnostic_note"],
                "available_previous_readings": len(
                    current["previous_readings"]
                ),
                "available_neighbour_readings": len(
                    current["neighbour_readings"]
                ),
            },
            indent=2,
        )

        try:
            conversation = [
                {
                    "role": "user",
                    "content": (
                        "Assess this sensor event:\n" + first_input
                    ),
                }
            ]

            for round_number in range(
                1,
                self.max_rounds + 1,
            ):
                response = self.client.responses.create(
                    model=self.model,
                    instructions=instructions,
                    input=conversation,
                    tools=self.tools,
                    tool_choice="auto",
                    store=False,
                )

                calls = [
                    item
                    for item in response.output
                    if getattr(item, "type", None)
                    == "function_call"
                ]

                if not calls:
                    raise RuntimeError(
                        "The model returned no tool call."
                    )

                conversation.extend(
                    [
                        item.model_dump(exclude_none=True)
                        if hasattr(item, "model_dump")
                        else item
                        for item in response.output
                    ]
                )

                tool_outputs = []

                for call in calls:
                    arguments = json.loads(call.arguments)

                    if call.name == "submit_final_decision":
                        action = arguments["action"]

                        if action not in self.FINAL_ACTIONS:
                            raise ValueError(
                                "Unsupported final action."
                            )

                        final_decision = {
                            "action": action,
                            "reason": arguments["reason"],
                        }

                        break

                    tool_result = self._execute_tool(
                        call.name,
                        arguments,
                        current,
                    )

                    tool_trace.append(
                        {
                            "round": round_number,
                            "tool": call.name,
                            "arguments": arguments,
                            "result": tool_result,
                            "worker_pid": os.getpid(),
                        }
                    )

                    tool_outputs.append(
                        {
                            "type": "function_call_output",
                            "call_id": call.call_id,
                            "output": json.dumps(tool_result),
                        }
                    )

                if final_decision is not None:
                    break

                conversation.extend(tool_outputs)

            if final_decision is None:
                raise RuntimeError(
                    "Maximum agent rounds reached."
                )

            return {
                **current,
                **final_decision,
                "decision_source": "parallel_openai_agent",
                "worker_pid": os.getpid(),
                "tool_trace": tool_trace,
                "audit": audit,
            }

        except Exception as exc:
            return {
                **current,
                "action": "human_review",
                "reason": (
                    f"Parallel agent failure: "
                    f"{type(exc).__name__}: {exc}"
                ),
                "decision_source": "agent_error_fallback",
                "worker_pid": os.getpid(),
                "tool_trace": tool_trace,
                "audit": audit,
            }


class DecisionMergePE(GenericPE):

    def __init__(self):
        super().__init__()

        self._add_input("deterministic")
        self._add_input("agent")
        self._add_output("output")

    def _process(self, inputs):
        if "deterministic" in inputs:
            return {"output": inputs["deterministic"]}

        if "agent" in inputs:
            return {"output": inputs["agent"]}

        return None


class ActionExecutorPE(IterativePE):

    def __init__(self):
        super().__init__()

    def _process(self, result):
        outcomes = {
            "accept": "Reading stored as valid.",
            "retry": "Another measurement was requested.",
            "maintenance": "Maintenance workflow initiated.",
            "notify_operator": "Operator was notified.",
            "human_review": "Case sent to human review.",
        }

        return {
            **result,
            "outcome": outcomes[result["action"]],
        }


class ResultWriterPE(ConsumerPE):

    def __init__(self):
        super().__init__()

    def _process(self, result):
        with open(
            OUTPUT_FILE,
            "a",
            encoding="utf-8",
        ) as handle:
            handle.write(json.dumps(result) + "\n")


read = ReadSensorDataPE()
read.name = "read"
read.numprocesses = 1

normalize = NormalizeDataPE()
normalize.numprocesses = 3

precheck = DeterministicPrecheckPE()
precheck.numprocesses = 3

agent = ParallelLLMSensorAgentPE(
    model=os.environ.get(
        "OPENAI_MODEL",
        "gpt-5-mini",
    )
)
agent.numprocesses = 4

merge = DecisionMergePE()
merge.numprocesses = 2

execute = ActionExecutorPE()
execute.numprocesses = 2

write_results = ResultWriterPE()
write_results.numprocesses = 1

graph = WorkflowGraph()

graph.connect(read, "output", normalize, "input")
graph.connect(normalize, "output", precheck, "input")

graph.connect(
    precheck,
    "resolved",
    merge,
    "deterministic",
)

graph.connect(
    precheck,
    "needs_agent",
    agent,
    "input",
)

graph.connect(
    agent,
    "output",
    merge,
    "agent",
)

graph.connect(merge, "output", execute, "input")
graph.connect(execute, "output", write_results, "input")
