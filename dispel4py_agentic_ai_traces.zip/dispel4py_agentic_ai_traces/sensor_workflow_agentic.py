from collections import defaultdict, deque
from datetime import datetime, timezone
from dispel4py.base import ConsumerPE, GenericPE, IterativePE, ProducerPE
from dispel4py.workflow_graph import WorkflowGraph
from openai import OpenAI
import json
import os


INPUT_FILE = "sensor_data_agentic.json"
OUTPUT_FILE = "agentic_sensor_results.jsonl"


def utc_now():
    return datetime.now(timezone.utc).isoformat()


class ReadSensorDataPE(ProducerPE):
    """Read the JSON file and emit one enriched event at a time."""

    def __init__(self):
        super().__init__()

    def _process(self, inputs):
        file_path = inputs["input"]

        with open(file_path, "r", encoding="utf-8") as handle:
            records = json.load(handle)

        for record in records:
            event = {
                "sensor_id": record["sensor_id"],
                "zone": record["zone"],
                "timestamp": record["timestamp"],
                "temperature": float(record["temperature"]),
                "humidity": float(record["humidity"]),
                "battery": int(record["battery"]),
                "diagnostic_note": record["diagnostic_note"],
                "audit": [
                    f"{utc_now()} ReadSensorDataPE emitted "
                    f"{record['sensor_id']}."
                ],
            }
            self.write("output", event)


class NormalizeDataPE(IterativePE):
    """Retain the familiar deterministic normalisation step."""

    def __init__(self):
        super().__init__()

    def _process(self, data):
        result = dict(data)
        result["normalized_temperature"] = result["temperature"] / 40.0
        result["audit"] = list(result["audit"]) + [
            f"{utc_now()} NormalizeDataPE normalised the temperature."
        ]
        return result


class DeterministicPrecheckPE(GenericPE):
    """
    Apply hard rules before the LLM is considered.

    This PE is not the LLM agent. It is a deterministic safety gate.
    """

    def __init__(self):
        super().__init__()
        self._add_input("input")
        self._add_output("resolved")
        self._add_output("needs_agent")

    def _process(self, inputs):
        event = dict(inputs["input"])
        audit = list(event["audit"])

        if event["battery"] < 10:
            audit.append(
                f"{utc_now()} DeterministicPrecheckPE selected maintenance "
                "because battery was below 10%."
            )
            return {
                "resolved": {
                    **event,
                    "action": "maintenance",
                    "reason": (
                        f"Battery is {event['battery']}%, below the fixed "
                        "10% maintenance threshold."
                    ),
                    "decision_source": "deterministic_rule",
                    "tool_trace": [],
                    "audit": audit,
                }
            }

        if event["temperature"] < -40 or event["temperature"] > 85:
            audit.append(
                f"{utc_now()} DeterministicPrecheckPE selected human_review "
                "because temperature was outside the fixed plausible range."
            )
            return {
                "resolved": {
                    **event,
                    "action": "human_review",
                    "reason": (
                        f"Temperature {event['temperature']}°C is outside "
                        "the fixed -40°C to 85°C range."
                    ),
                    "decision_source": "deterministic_rule",
                    "tool_trace": [],
                    "audit": audit,
                }
            }

        audit.append(
            f"{utc_now()} No hard rule applied; event sent to "
            "LLMSensorAgentPE."
        )
        return {"needs_agent": {**event, "audit": audit}}


class LLMSensorAgentPE(IterativePE):
    """
    A stateful, tool-using agent implemented inside one dispel4py PE.

    The agent can inspect evidence, invoke bounded Python tools, observe their
    results, and continue until it submits a final decision.
    """

    FINAL_ACTIONS = {
        "accept",
        "retry",
        "maintenance",
        "notify_operator",
        "human_review",
    }

    EVIDENCE_TOOLS = {
        "inspect_previous_readings",
        "compare_neighbouring_sensors",
        "request_another_measurement",
    }

    def __init__(
        self,
        neighbour_map,
        model="gpt-5-mini",
        history_size=5,
        max_rounds=6,
    ):
        super().__init__()
        self.neighbour_map = neighbour_map
        self.model = model
        self.history_size = history_size
        self.max_rounds = max_rounds

        self.client = None
        self.history = defaultdict(lambda: deque(maxlen=history_size))
        self.latest_by_sensor = {}

        # These collections simulate external systems.
        self.measurement_requests = []
        self.maintenance_tickets = []
        self.operator_notifications = []
        self.human_review_queue = []

        self.tools = self._build_tools()

    def preprocess(self):
        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError(
                "OPENAI_API_KEY is missing. Run the API-key cell first."
            )
        self.client = OpenAI()

    def _build_tools(self):
        return [
            {
                "type": "function",
                "name": "inspect_previous_readings",
                "description": (
                    "Inspect up to five recent readings from the current "
                    "sensor before deciding."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "sensor_id": {"type": "string"},
                        "limit": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 5,
                        },
                    },
                    "required": ["sensor_id", "limit"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "compare_neighbouring_sensors",
                "description": (
                    "Compare the current reading with the most recent readings "
                    "from configured neighbouring sensors."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "sensor_id": {"type": "string"},
                    },
                    "required": ["sensor_id"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "request_another_measurement",
                "description": (
                    "Create a simulated request for another measurement when "
                    "a temporary communication or sampling issue is suspected."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "sensor_id": {"type": "string"},
                        "reason": {"type": "string"},
                    },
                    "required": ["sensor_id", "reason"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "create_maintenance_ticket",
                "description": (
                    "Create a simulated maintenance ticket for likely "
                    "hardware, battery, calibration, or enclosure problems."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "sensor_id": {"type": "string"},
                        "reason": {"type": "string"},
                        "priority": {
                            "type": "string",
                            "enum": ["low", "medium", "high"],
                        },
                    },
                    "required": ["sensor_id", "reason", "priority"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "notify_operator",
                "description": (
                    "Create a simulated operator notification for an event "
                    "that should be visible to operations staff."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "sensor_id": {"type": "string"},
                        "message": {"type": "string"},
                        "severity": {
                            "type": "string",
                            "enum": ["info", "warning", "critical"],
                        },
                    },
                    "required": ["sensor_id", "message", "severity"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "escalate_to_human",
                "description": (
                    "Create a simulated human-review item for ambiguous, "
                    "contradictory, or safety-relevant cases."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "sensor_id": {"type": "string"},
                        "reason": {"type": "string"},
                    },
                    "required": ["sensor_id", "reason"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "submit_final_decision",
                "description": (
                    "Finish the agent loop by submitting exactly one final "
                    "bounded action and a concise reason."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": [
                                "accept",
                                "retry",
                                "maintenance",
                                "notify_operator",
                                "human_review",
                            ],
                        },
                        "reason": {"type": "string"},
                    },
                    "required": ["action", "reason"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
        ]

    # ----------------------- deterministic tools -----------------------

    def inspect_previous_readings(self, sensor_id, limit, current):
        previous = list(self.history[sensor_id])[-limit:]
        return {
            "sensor_id": sensor_id,
            "count": len(previous),
            "previous_readings": previous,
            "current_reading_excluded": True,
        }

    def compare_neighbouring_sensors(self, sensor_id, current):
        neighbours = []

        for neighbour_id in self.neighbour_map.get(sensor_id, []):
            latest = self.latest_by_sensor.get(neighbour_id)
            if latest:
                neighbours.append(
                    {
                        "sensor_id": neighbour_id,
                        "timestamp": latest["timestamp"],
                        "temperature": latest["temperature"],
                        "humidity": latest["humidity"],
                    }
                )

        differences = [
            {
                "sensor_id": item["sensor_id"],
                "temperature_difference": round(
                    current["temperature"] - item["temperature"], 2
                ),
                "humidity_difference": round(
                    current["humidity"] - item["humidity"], 2
                ),
            }
            for item in neighbours
        ]

        return {
            "sensor_id": sensor_id,
            "neighbours_found": len(neighbours),
            "neighbour_readings": neighbours,
            "differences_from_current": differences,
        }

    def request_another_measurement(self, sensor_id, reason, current):
        request = {
            "request_id": f"RM-{len(self.measurement_requests) + 1:04d}",
            "sensor_id": sensor_id,
            "reason": reason,
            "created_at": utc_now(),
            "status": "simulated",
        }
        self.measurement_requests.append(request)
        return request

    def create_maintenance_ticket(
        self, sensor_id, reason, priority, current
    ):
        ticket = {
            "ticket_id": f"MT-{len(self.maintenance_tickets) + 1:04d}",
            "sensor_id": sensor_id,
            "priority": priority,
            "reason": reason,
            "created_at": utc_now(),
            "status": "simulated",
        }
        self.maintenance_tickets.append(ticket)
        return ticket

    def notify_operator(self, sensor_id, message, severity, current):
        notification = {
            "notification_id": (
                f"OP-{len(self.operator_notifications) + 1:04d}"
            ),
            "sensor_id": sensor_id,
            "severity": severity,
            "message": message,
            "created_at": utc_now(),
            "status": "simulated",
        }
        self.operator_notifications.append(notification)
        return notification

    def escalate_to_human(self, sensor_id, reason, current):
        review = {
            "review_id": f"HR-{len(self.human_review_queue) + 1:04d}",
            "sensor_id": sensor_id,
            "reason": reason,
            "created_at": utc_now(),
            "status": "simulated",
        }
        self.human_review_queue.append(review)
        return review

    def _execute_tool(self, name, arguments, current):
        tool_map = {
            "inspect_previous_readings": self.inspect_previous_readings,
            "compare_neighbouring_sensors": (
                self.compare_neighbouring_sensors
            ),
            "request_another_measurement": (
                self.request_another_measurement
            ),
            "create_maintenance_ticket": (
                self.create_maintenance_ticket
            ),
            "notify_operator": self.notify_operator,
            "escalate_to_human": self.escalate_to_human,
        }

        if name not in tool_map:
            raise ValueError(f"Tool is not permitted: {name}")

        return tool_map[name](current=current, **arguments)

    # -------------------------- agent loop -----------------------------

    def _process(self, event):
        if self.client is None:
            self.preprocess()

        current = dict(event)
        audit = list(current["audit"])
        tool_trace = []
        final_decision = None

        instructions = """
You are LLMSensorAgent, a bounded IoT sensor agent inside a dispel4py
streaming workflow.

Your goal is to assess one sensor event safely.

You may gather evidence by inspecting previous readings, comparing
neighbouring sensors, or requesting another measurement. You may also create
a maintenance ticket, notify an operator, or escalate to a human.

Rules:
- Never invent or modify measurements.
- Prefer deterministic tool evidence over speculation.
- Use at least one evidence-gathering tool before accepting an event that
  contains a warning, uncertainty, packet loss, moisture, buzzing, drift, or
  another possible fault.
- Create a maintenance ticket only for likely equipment, enclosure, battery,
  or calibration problems.
- Escalate ambiguous or safety-relevant cases to a human.
- Finish by calling submit_final_decision.
- If you request another measurement, the final action should normally be
  retry.
- If you create a maintenance ticket, the final action must be maintenance.
- If you escalate to a human, the final action must be human_review.
"""

        first_input = (
            "Assess this sensor event:\n"
            + json.dumps(
                {
                    "sensor_id": current["sensor_id"],
                    "zone": current["zone"],
                    "timestamp": current["timestamp"],
                    "temperature": current["temperature"],
                    "normalized_temperature": (
                        current["normalized_temperature"]
                    ),
                    "humidity": current["humidity"],
                    "battery": current["battery"],
                    "diagnostic_note": current["diagnostic_note"],
                },
                indent=2,
            )
        )

        try:
            # Keep the complete conversation locally. This is compatible with
            # OpenAI organisations that use Zero Data Retention because the
            # workflow does not rely on previous_response_id.
            conversation = [
                {
                    "role": "user",
                    "content": first_input,
                }
            ]

            for round_number in range(1, self.max_rounds + 1):
                response = self.client.responses.create(
                    model=self.model,
                    instructions=instructions,
                    input=conversation,
                    tools=self.tools,
                    tool_choice="auto",
                    store=False,
                )

                calls = [
                    item
                    for item in response.output
                    if getattr(item, "type", None) == "function_call"
                ]

                if not calls:
                    raise RuntimeError(
                        "The model returned no tool call or final decision."
                    )

                # Preserve the model output locally so the next request can see
                # the function calls without server-side response storage.
                conversation.extend(
                    [
                        item.model_dump(exclude_none=True)
                        if hasattr(item, "model_dump")
                        else item
                        for item in response.output
                    ]
                )

                tool_outputs = []

                for call in calls:
                    arguments = json.loads(call.arguments)

                    if call.name == "submit_final_decision":
                        action = arguments["action"]
                        reason = arguments["reason"]

                        if action not in self.FINAL_ACTIONS:
                            raise ValueError(
                                "Final action was outside the permitted set."
                            )

                        final_decision = {
                            "action": action,
                            "reason": reason,
                        }
                        audit.append(
                            f"{utc_now()} LLMSensorAgentPE submitted "
                            f"{action}: {reason}"
                        )
                        break

                    tool_result = self._execute_tool(
                        call.name,
                        arguments,
                        current,
                    )

                    tool_trace.append(
                        {
                            "round": round_number,
                            "tool": call.name,
                            "arguments": arguments,
                            "result": tool_result,
                        }
                    )
                    audit.append(
                        f"{utc_now()} LLMSensorAgentPE called "
                        f"{call.name}."
                    )

                    tool_outputs.append(
                        {
                            "type": "function_call_output",
                            "call_id": call.call_id,
                            "output": json.dumps(tool_result),
                        }
                    )

                if final_decision is not None:
                    break

                # Add the locally executed tool results. The complete list is
                # sent again in the next round.
                conversation.extend(tool_outputs)

            if final_decision is None:
                raise RuntimeError(
                    "Maximum agent rounds reached without a final decision."
                )

            result = {
                **current,
                **final_decision,
                "decision_source": "openai_tool_using_agent",
                "tool_trace": tool_trace,
                "audit": audit,
            }

        except Exception as exc:
            reason = (
                f"Agent or API failure: {type(exc).__name__}: {exc}"
            )
            review = self.escalate_to_human(
                sensor_id=current["sensor_id"],
                reason=reason,
                current=current,
            )
            tool_trace.append(
                {
                    "round": None,
                    "tool": "escalate_to_human",
                    "arguments": {
                        "sensor_id": current["sensor_id"],
                        "reason": reason,
                    },
                    "result": review,
                    "fallback": True,
                }
            )
            audit.append(
                f"{utc_now()} Safe fallback sent the event to human review."
            )

            result = {
                **current,
                "action": "human_review",
                "reason": reason,
                "decision_source": "agent_error_fallback",
                "tool_trace": tool_trace,
                "audit": audit,
            }

        # Update memory only after the decision, so "previous" excludes current.
        self.history[current["sensor_id"]].append(
            {
                "timestamp": current["timestamp"],
                "temperature": current["temperature"],
                "humidity": current["humidity"],
                "battery": current["battery"],
                "diagnostic_note": current["diagnostic_note"],
                "final_action": result["action"],
            }
        )
        self.latest_by_sensor[current["sensor_id"]] = current

        return result


class DecisionMergePE(GenericPE):
    """Merge the deterministic and LLM-agent branches."""

    def __init__(self):
        super().__init__()
        self._add_input("deterministic")
        self._add_input("agent")
        self._add_output("output")

    def _process(self, inputs):
        if "deterministic" in inputs:
            return {"output": inputs["deterministic"]}
        if "agent" in inputs:
            return {"output": inputs["agent"]}
        return None


class ActionExecutorPE(IterativePE):
    """
    Execute the selected bounded action.

    This tutorial records simulated actions rather than controlling devices.
    """

    def __init__(self):
        super().__init__()

    def _process(self, decision):
        outcomes = {
            "accept": "Reading stored as valid.",
            "retry": "A follow-up measurement was requested.",
            "maintenance": "Maintenance workflow initiated.",
            "notify_operator": "Operator notification recorded.",
            "human_review": "Case placed in human-review queue.",
        }

        action = decision["action"]

        if action not in outcomes:
            raise ValueError(f"Unsupported final action: {action}")

        result = {
            **decision,
            "outcome": outcomes[action],
            "audit": list(decision["audit"])
            + [
                f"{utc_now()} ActionExecutorPE: "
                f"{outcomes[action]}"
            ],
        }

        print(
            "AGENTIC RESULT:",
            result["sensor_id"],
            "->",
            result["action"],
            f"({result['decision_source']})",
        )

        return result


class ResultWriterPE(ConsumerPE):
    """Write every final event to a JSON Lines file."""

    def __init__(self, output_file=OUTPUT_FILE):
        super().__init__()
        self.output_file = output_file

    def _process(self, result):
        with open(self.output_file, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(result) + "\n")


NEIGHBOUR_MAP = {
    "sensor-001": ["sensor-002"],
    "sensor-002": ["sensor-001"],
    "sensor-003": ["sensor-004"],
    "sensor-004": ["sensor-003"],
}


read = ReadSensorDataPE()
read.name = "read"

normalize = NormalizeDataPE()
precheck = DeterministicPrecheckPE()
agent = LLMSensorAgentPE(
    neighbour_map=NEIGHBOUR_MAP,
    model=os.environ.get("OPENAI_MODEL", "gpt-5-mini"),
)
merge = DecisionMergePE()
execute = ActionExecutorPE()
write_results = ResultWriterPE()

graph = WorkflowGraph()
graph.connect(read, "output", normalize, "input")
graph.connect(normalize, "output", precheck, "input")
graph.connect(precheck, "resolved", merge, "deterministic")
graph.connect(precheck, "needs_agent", agent, "input")
graph.connect(agent, "output", merge, "agent")
graph.connect(merge, "output", execute, "input")
graph.connect(execute, "output", write_results, "input")
